<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<link rel="stylesheet" href="assets/css/custom.css">
<a href="items.php" class="btn btn-default">View All Items</a>
<a href="itemCreate.php" class="btn btn-default">Create New Item</a>
<a href="upload.php" class="btn btn-default">Upload Data File</a>
<hr>